import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWritingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
		FileOutputStream file = new FileOutputStream("new.txt", true); //if file exists already=true
																		//so append
		
		System.out.println("File is ready for writing..");
		
		String str = "3rd line writing to the file..";
		byte barray[] = str.getBytes();
		
		System.out.println("String is converted into byte array..");
		
		file.write(barray);
		System.out.println("Written to file..");
		
		file.close();
		System.out.println("File is closed");
		
		} 
		catch (FileNotFoundException e) {
			System.out.println("Exception: "+e);
		} 
		catch (IOException e) {
			System.out.println("Exception: "+e);		
		}

	}

}
