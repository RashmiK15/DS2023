import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileReadingTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		MyFileReader file1 = new MyFileReader("King");
		MyFileReader file2 = new MyFileReader("Queen");
		MyFileReader file3 = new MyFileReader("Prince");

		file1.readFile();
		file1.closeFile();
		
		System.out.println("----------------------");
		
		file2.readFile();
		file2.closeFile();
		
		System.out.println("----------------------");
		
		file3.readFile();
		file3.closeFile();
		
		System.out.println("----------------------");
		
	}

}
class MyFileReader{
	
	FileInputStream file; //hasA
	
	public MyFileReader(String filename) {
		try {
			file = new FileInputStream(filename);
			
		}
		catch(FileNotFoundException e) {
			System.out.println("Exception: "+e);
		}
	}
	
	
	public void readFile() {
		System.out.println("File is open..");
		byte b;
		try {
			b = (byte) file.read();
		
			while(b!=-1) {
			
			System.out.print((char)b);
			
				b = (byte) file.read();
			 
			
				Thread.sleep(5);
			}
			
		}
			catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	public void closeFile() {
		
		System.out.println("Closing the file..");
		
		try {
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("File is closed..");
	}
	
}