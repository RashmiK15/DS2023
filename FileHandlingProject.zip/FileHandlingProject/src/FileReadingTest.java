import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;

public class FileReadingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String path = "\\C:\\Users\\RKI37\\eclipse-workspace\\MyFirstProject\\src\\";
		String file = "King.txt";
		
		func(path+file);
			
		file = "Queen.txt";
		
		func(path+file);
		
		file = "Prince.txt";
		
		func(path+file);
			
			
	}

static void func(String path) {
	
	try {
		
		
		System.out.println("Openeing the file..");
		FileInputStream file = new FileInputStream("\\C:\\Users\\RKI37\\eclipse-workspace\\MyFirstProject\\src\\King.txt");
		System.out.println("File is open..");
		byte b = (byte) file.read();
		
		
		
		while(b!=-1) {
			
			System.out.print((char)b);
			b = (byte) file.read();
			Thread.sleep(5);
		}
		
		
		System.out.println("Closing the file..");
		
		file.close();
		
		System.out.println("File is closed..");
	
	
	} 
	
	catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("Exception: "+e);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("Exception: "+e);
	} catch (InterruptedException e) {//for sleep // if sleep is interrupted
		// TODO Auto-generated catch block
		System.out.println("Exception: "+e);
	}
}

}