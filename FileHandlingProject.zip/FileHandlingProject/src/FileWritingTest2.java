import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FileWritingTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame frame = new MyFrame();
		frame.setVisible(true);

		
	}

}

class MyFrame extends JFrame implements ActionListener {  //isA
	
	JLabel label1 = new JLabel("Enter filename"); //hasA
	JTextField filename = new JTextField(20); //hasA
	
	JLabel label2 = new JLabel("Enter data"); //hasA
	JTextArea dataArea = new JTextArea(15, 20); //hasA
	
	JButton save = new JButton("save"); //hasA
	JButton clear = new JButton("clear"); //hasA
	
	MyFrame(){
		
		setLayout(new FlowLayout());
		setSize(400, 500);
		setLocation(100, 100);
		setTitle("My Notepad");
		add(label1);
		add(filename);
		add(label2);
		add(dataArea);
		add(save);
		add(clear);
		save.addActionListener(this);
		clear.addActionListener(this);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) { //usesA
		// TODO Auto-generated method stub
		if(e.getSource() == save) {
			System.out.println("Save is clicked..");
		
			try {
				
				FileOutputStream file = new FileOutputStream(filename.getText(), true);
				System.out.println("File is ready for writing..");
				
				byte barray[] = dataArea.getText().getBytes();
				
				System.out.println("String is converted into byte array..");
				
				file.write(barray);
				System.out.println("Written to file..");
				
				JOptionPane.showMessageDialog(this,  "File is saved.");
				
				file.close();
				System.out.println("File is closed");
				
			}
			
			catch (FileNotFoundException e1) {
				System.out.println("Exception: "+e1);
				JOptionPane.showMessageDialog(this,  e1.getMessage());
			} 
			catch (IOException e1) {
				System.out.println("Exception: "+e1);		
			}
		}
		else {
			System.out.println("Clear button is clicked..");
			dataArea.setText("");
		
		}
	}
}