package com.java;

import java.util.Date;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//   project folder ---><-- web.xml
//http://localhost:port/RestAPI/rest/  currency/greet
@Path("/insurance")
public class AccountHolder {

	//global list
	static List<Account> accList = new ArrayList<Account>();
	
	static {
		
		System.out.println("Invoked only once..");
		
		Account ac1 = new Account();
		ac1.setPolicyNumber(1);
		ac1.setName("Jane");
		ac1.setAge(25);
		ac1.setAdharNumber(123456781234D);
		ac1.setCarModel("Maruti Suzuki India LTD");
		ac1.setDrivingLicence("KA12345678912345");
		ac1.setDuration(1);
		ac1.setEngineNumber(4008332);
		ac1.setPlan("Comprehensive");
		ac1.setRegistrationNumber("KA12QP1234");
		ac1.setIssuedDate(new Date(2023-02-04));
		ac1.setExpireDate(new Date(2024-02-04));
		
		Account ac2 = new Account();
		ac2.setPolicyNumber(2);
		ac2.setName("Ram");
		ac2.setAge(30);
		ac2.setAdharNumber(234567812314D);
		ac2.setCarModel("THE NEW BALENO BS-VI SIGMA");
		ac2.setDrivingLicence("MH12345678912345");
		ac2.setDuration(2);
		ac2.setEngineNumber(4300832);
		ac2.setPlan("Comprehensive");
		ac2.setRegistrationNumber("MH12QP1234");
		ac1.setIssuedDate(new Date(2021-03-14));
		ac1.setExpireDate(new Date(2023-03-14));
		
		Account ac3 = new Account();
		ac3.setPolicyNumber(3);
		ac3.setName("Chen");
		ac3.setAge(29);
		ac3.setAdharNumber(781122345634D);
		ac3.setCarModel("HONDA CITY");
		ac3.setDrivingLicence("DL12345678912345");
		ac3.setDuration(1);
		ac3.setEngineNumber(3340082);
		ac3.setPlan("Third Party");
		ac3.setRegistrationNumber("DL12QP1234");
		ac1.setIssuedDate(new Date(2023-01-28));
		ac1.setExpireDate(new Date(2024-01-28));
		
		accList.add(ac1);
		accList.add(ac2);
		accList.add(ac3);
		
	}
	
	public AccountHolder() {
		System.out.println("AccountHolder ctr() called..");
		
	}

	@GET()
	@Path("/greet")//action mapping
	public String welcome() {
		return ("<h1> Welcome to Motor Vehicle Insurance</h1>"+"<marquee><h2>Insure with us and stay safe!</h2></marquee>");
	}
	
	@GET()
	@Path("/viewAll")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Account>convertAll(){
		return accList;
	}
	
	@GET()
	@Path("/view/{policy}")
	@Produces(MediaType.APPLICATION_JSON)
	public Account viewIt(@PathParam("policy") int x) {
		
		Account ac=null;
		for(Account account : accList) {
			if(account.getPolicyNumber()==x) {
				ac = account;
				break;
			}
		}
		return ac;
	}
	
	@DELETE
	@Path("/delete/{id}")
	public String delete(@PathParam("id") int y) {
		
		boolean found = false;
		for(Account account : accList) {
			if(account.getPolicyNumber()==y) {
				accList.remove(account);
				found = true;
				break;
			}
		}
		if(found==true)
			return "Deleted";
		else
			return ("Not found"+y);
	}
	
	@POST()
	@Path("/addpolicy")
	public String add(Account currObj) {
		
		boolean flag=false;
		for(Account account : accList) {
			if(account.getPolicyNumber() == currObj.getPolicyNumber()) {
				flag=true;
			}
		}
		if(flag==true) {
			return "Policy already exists!";
		}
		
		accList.add(currObj);
		return "Policy added";
	}
	
	@PUT
	@Path("/renew")
	public String modify(Account currObj) {
		boolean flag = false;
		for(Account account : accList) {
			if(account.getPolicyNumber() == currObj.getPolicyNumber()) {
				flag = true;
				accList.remove(account);
				break;
			}
		}
		if(flag == true) {
			accList.add(currObj);
			return "Policy renewed";
		}
		return "Policy not found";
	}
}
