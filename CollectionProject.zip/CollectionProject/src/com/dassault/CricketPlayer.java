package com.dassault;

class CricketPlayer extends Player{ //isA
	
	int rank;
	String name;
	String country;
	int totalRunsMadeTillNow;
	int totalFourRunsHit;
	int totalSixRunsHit;
	int currentRun;
	int age;
	float strikeRate;
	
	

	
	
	public CricketPlayer(int rank, String name, String country, int totalRunsMadeTillNow, int totalFourRunsHit,
			int totalSixRunsHit, int currentRun, int age, float strikeRate) {
		super();
		this.rank = rank;
		this.name = name;
		this.country = country;
		this.totalRunsMadeTillNow = totalRunsMadeTillNow;
		this.totalFourRunsHit = totalFourRunsHit;
		this.totalSixRunsHit = totalSixRunsHit;
		this.currentRun = currentRun;
		this.age = age;
		this.strikeRate = strikeRate;
	}



	@Override
	public String toString() {
		return "CricketPlayer [rank=" + rank + ", name=" + name + ", country=" + country + ", totalRunsMadeTillNow="
				+ totalRunsMadeTillNow + ", totalFourRunsHit=" + totalFourRunsHit + ", totalSixRunsHit="
				+ totalSixRunsHit + ", currentRun=" + currentRun + ", age=" + age + ", strikeRate=" + strikeRate + "]";
	}



	void printCricketPlayer() {
		
		System.out.println("Rank: "+rank);
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Country: "+country);
		System.out.println("Total Runs: "+totalRunsMadeTillNow);
		System.out.println("Total Fours: "+totalFourRunsHit);
		System.out.println("Total Sixers: "+totalSixRunsHit);
		System.out.println("Current Run: "+currentRun);
		System.out.println("Strike Rate: "+strikeRate);
		System.out.println("----------------------");
		
	}
	
}