package com.dassault;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Scanner;

public class DynamicEntryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList playerList = new LinkedList();
		
		
		int choice=0;
		int rank=0;
		
		do {
			
			//rank,name,hits,hitf, sr, totrun, currRun 
			Scanner scan1 = new Scanner(System.in);
			System.out.println("Enter player name:\n");
			String playerName = scan1.nextLine();
			
			Scanner scan2 = new Scanner(System.in);
			System.out.println("Enter number of six hits:\n");
			int hitSix = scan2.nextInt();
			
			Scanner scan3 = new Scanner(System.in);
			System.out.println("Enter number of four hits:\n");
			int hitFour = scan2.nextInt();
			
			Scanner scan4 = new Scanner(System.in);
			System.out.println("Enter current run : ");
			int currentRun = scan4.nextInt();
			
			Scanner scan5 = new Scanner(System.in);
			System.out.println("Enter age  : ");
			int age = scan5.nextInt();
			
			Scanner scan6 = new Scanner(System.in);
			System.out.println("Enter strike rate : ");
			float  strikeRt = scan6.nextFloat();
			
			Scanner scan7 = new Scanner(System.in);
			System.out.println("Enter total score till now : ");
			int totalScore = scan7.nextInt();
			
			CricketPlayer player = new CricketPlayer(++rank, playerName, "India", totalScore, hitSix, hitFour, currentRun, age, strikeRt);
			
			playerList.add(player); //new player of CricketPlayer object type added
			
			Scanner scanChoice = new Scanner(System.in);
			System.out.println("Enter 0 to continue or 1 to exit\n");
			choice=scanChoice.nextInt();
			
			
		}while(choice==0);
		
		Iterator teamIndia = playerList.iterator();
		
		while (teamIndia.hasNext()) {
			CricketPlayer x = (CricketPlayer) teamIndia.next();
			x.printCricketPlayer();
		}
		
		
		
		for (int i = 0; i < playerList.size(); i++) { //its 11 - 5 are assigned
			CricketPlayer x = (CricketPlayer) playerList.get(i);
			x.printCricketPlayer();	
		}
		
		
		for (Object object : playerList) {
			CricketPlayer x = (CricketPlayer) object;
			x.printCricketPlayer();
		}
		

	}

}
