package com.dassault;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet numberSet = new TreeSet();
		
		numberSet.add(10);
		numberSet.add(20);
		numberSet.add(30);
		
		Iterator itr = numberSet.iterator();
		
		while(itr.hasNext()) {
			int intValue = (Integer) itr.next();
			System.out.println("num : "+intValue);
		}
		
		System.out.println("-----------");
		
		TreeSet chemicalElementSet = new TreeSet();
		
		chemicalElementSet.add("Oxygen");
		chemicalElementSet.add("Hydrogen");
		chemicalElementSet.add("Lithium");
		chemicalElementSet.add("Silver");
		chemicalElementSet.add("Gold");
		chemicalElementSet.add("Aluminium");
		chemicalElementSet.add("Helium");
		
		
		Iterator chemicalElementIter = chemicalElementSet.iterator();
		
		while(chemicalElementIter.hasNext()) {
			String strValue = (String) chemicalElementIter.next();
			System.out.println("Chemical : "+strValue);
		}
		
	}

}
