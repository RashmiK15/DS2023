/*
public class ArraysOfObjectsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//content
		CricketPlayer player1 = new CricketPlayer(3, "Sachin Tendulkar", "India", 12000, 300, 200, 89, 25, 78.3f);
		CricketPlayer player2 = new CricketPlayer(5, "Virat Kohli", "India", 12000, 300, 200, 89, 25, 78.3f);
		CricketPlayer player3 = new CricketPlayer(1, "Yuvraj Singh", "India", 12000, 300, 200, 89, 25, 78.3f);
		CricketPlayer player4 = new CricketPlayer(8, "Virendra Sehwag", "India", 12000, 300, 200, 89, 25, 78.3f);
		CricketPlayer player5 = new CricketPlayer(4, "MS Dhoni", "India", 12000, 300, 200, 89, 25, 78.3f);
		
		//container
		CricketPlayer teamIndia[] = new CricketPlayer[11];
		
		//adding the content in the container
		teamIndia[0] = player1;
		teamIndia[1] = player2;
		teamIndia[2] = player3;
		teamIndia[3] = player4;
		teamIndia[4] = player5;
		
		try {
		for(int i=0; i<teamIndia.length; i++) {
			
			CricketPlayer x = teamIndia[i];
			
			x.printCricketPlayer();
			System.out.println("------------------");
		}
		
		}
		catch(NullPointerException e){
			
			System.out.println(e.getMessage());
		}
		
	}

}

class Player{
	
	
}

class CricketPlayer extends Player{ //isA
	
	int rank;
	String name;
	String country;
	int totalRunsMadeTillNow;
	int totalFourRunsHit;
	int totalSixRunsHit;
	int currentRun;
	int age;
	float strikeRate;
	
	

	
	
	public CricketPlayer(int rank, String name, String country, int totalRunsMadeTillNow, int totalFourRunsHit,
			int totalSixRunsHit, int currentRun, int age, float strikeRate) {
		super();
		this.rank = rank;
		this.name = name;
		this.country = country;
		this.totalRunsMadeTillNow = totalRunsMadeTillNow;
		this.totalFourRunsHit = totalFourRunsHit;
		this.totalSixRunsHit = totalSixRunsHit;
		this.currentRun = currentRun;
		this.age = age;
		this.strikeRate = strikeRate;
	}



	@Override
	public String toString() {
		return "CricketPlayer [rank=" + rank + ", name=" + name + ", country=" + country + ", totalRunsMadeTillNow="
				+ totalRunsMadeTillNow + ", totalFourRunsHit=" + totalFourRunsHit + ", totalSixRunsHit="
				+ totalSixRunsHit + ", currentRun=" + currentRun + ", age=" + age + ", strikeRate=" + strikeRate + "]";
	}



	void printCricketPlayer() {
		
		System.out.println("Rank: "+rank);
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Country: "+country);
		System.out.println("Total Runs: "+totalRunsMadeTillNow);
		System.out.println("Total Fours: "+totalFourRunsHit);
		System.out.println("Total Sixers: "+totalSixRunsHit);
		System.out.println("Current Run: "+currentRun);
		System.out.println("Strike Rate: "+strikeRate);
		
	}
	
}
*/