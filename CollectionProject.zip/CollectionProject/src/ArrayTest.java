
public class ArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int teamIndia[] = new int[11];
		
		teamIndia[0] = 89;
		teamIndia[1] = 99;
		teamIndia[2] = 19;
		teamIndia[3] = 82;
		teamIndia[4] = 37;
		
		int totalScore = 0;
		
		for(int i=0; i<teamIndia.length; i++) {
			System.out.println("batsman "+i+": "+teamIndia[i]);
			totalScore=totalScore+teamIndia[i];
		}
		
		System.out.println("Total Score: "+totalScore);
		
//		System.out.println("batsman1: "+batsman1);
//		System.out.println("batsman2: "+batsman2);
//		System.out.println("batsman3: "+batsman3);
//		System.out.println("batsman4: "+batsman4);
//		System.out.println("batsman5: "+batsman5);
//		
//		int totalScore = batsman1+batsman2+batsman3+batsman4+batsman5;
//		System.out.println("Total score: "+totalScore);
	}

}
