package com.java;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//   project folder ---><-- web.xml
//http://localhost:port/RestAPI/rest/  currency/greet
@Path("/currency")
public class CurrencyService {

	//global list
	static List<Currency> currList = new ArrayList<Currency>();
	
	static {
		
		System.out.println("Invoked only once..");
		
		Currency curr1 = new Currency();
		curr1.setCurrencyId(1);
		curr1.setSourceCurrency("USD");
		curr1.setTargetCurrency("INR");
		curr1.setAmountToConvert(500);
		
		Currency curr2 = new Currency();
		curr2.setCurrencyId(2);
		curr2.setSourceCurrency("EUROS");
		curr2.setTargetCurrency("INR");
		curr2.setAmountToConvert(600);
		
		Currency curr3 = new Currency();
		curr3.setCurrencyId(3);
		curr3.setSourceCurrency("DIN");
		curr3.setTargetCurrency("INR");
		curr3.setAmountToConvert(700);
		
		currList.add(curr1);
		currList.add(curr2);
		currList.add(curr3);
	}
	
	public CurrencyService() {
		System.out.println("Currency Service called..");
		
	}

	@GET()
	@Path("/greet")//action mapping
	public String welcome() {
		return "<h1> Welcome to Web based services</h1>";
	}
	
	@GET()
	@Path("/convertIt/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Currency convertIt(@PathParam("cid") int x) {
		
		Currency curr=null;
		for(Currency currency : currList) {
			if(currency.getCurrencyId()==x) {
				curr = currency;
				break;
			}
		}
		return curr;
	}
	
	@DELETE
	@Path("/delete/{id}")
	public String delete(@PathParam("id") int y) {
		
		boolean found = false;
		for(Currency currency : currList) {
			if(currency.getCurrencyId()==y) {
				//curr = currency;
				currList.remove(currency);
				found = true;
				break;
			}
		}
		if(found==true)
			return "Deleted";
		else
			return ("Not found"+y);
	}
	
	@POST()
	@Path("/add")
	public String add(Currency currObj) {
		
		boolean flag=false;
		for(Currency currency : currList) {
			if(currency.getCurrencyId() == currObj.getCurrencyId()) {
				flag=true;
			}
		}
		if(flag==true) {
			return "Data already exists";
		}
		
		currList.add(currObj);
		return "Data added";
	}
	
	@PUT
	@Path("/update")
	public String modify(Currency currObj) {
		boolean flag = false;
		Currency curr=null;
		for(Currency currency : currList) {
			if(currency.getCurrencyId() == currObj.getCurrencyId()) {
				flag = true;
				currList.remove(currency);
				break;
			}
		}
		if(flag == true) {
			currList.add(currObj);
			return "Currency modified";
		}
		return "Not found";
	}

	
	///Add more than one----------------------------------------------------------------------------------------------
	/*
	@POST()
	@Path("/add")
	public String add(Currency currObj[]) {
		
		boolean flag=false;
		while(currObj.)
		for(Currency currency : currList) {
			if(currency.getCurrencyId() == currObj.getCurrencyId()) {
				flag=true;
			}
		}
		if(flag==true) {
			return "Data already exists";
		}
		
		currList.add(currObj);
		return "Data added";
	}
	*/
	///---------------------------------------------------------------------------------------------------------------
	
	@GET()
	@Path("/convertAll")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Currency>convertAll(){
		return currList;
	}
	
}
