package com.java;

import java.time.LocalDate;
import java.util.Date;

public class Account {

	private int policyNumber;
	private String name;
	private int age;
	private double adharNumber;
	private String plan;
	private int duration;
	private String carModel;
	private String drivingLicence;
	private String registrationNumber;
	private int engineNumber;
	private Date issuedDate;
	private Date expireDate;
	
	
	public Account() {
		System.out.println("In account ctr()..");
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public double getAdharNumber() {
		return adharNumber;
	}


	public void setAdharNumber(double l) {
		this.adharNumber = l;
	}


	public String getPlan() {
		return plan;
	}


	public void setPlan(String plan) {
		this.plan = plan;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public String getCarModel() {
		return carModel;
	}


	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}


	public String getDrivingLicence() {
		return drivingLicence;
	}


	public void setDrivingLicence(String drivingLicence) {
		this.drivingLicence = drivingLicence;
	}


	public String getRegistrationNumber() {
		return registrationNumber;
	}


	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}


	public int getEngineNumber() {
		return engineNumber;
	}


	public void setEngineNumber(int engineNumber) {
		this.engineNumber = engineNumber;
	}


	public int getPolicyNumber() {
		return policyNumber;
	}


	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}


	public Date getIssuedDate() {
		return issuedDate;
	}


	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}


	public Date getExpireDate() {
		return expireDate;
	}


	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
	
}
