package dao;

import java.util.List;

public class TestDao {

	public static void main(String[] args) {
		
		//DELETE
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
		
		empDaoImpl.deleteEmployee(104);
		
		
		
		//UPDATE
		/*
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
		
		Employee employee = new Employee();
		
		employee.setEmployeeNumber(104);
		employee.setEmployeeName("CLARK");
		employee.setEmployeeJob("CLERK");
		employee.setEmployeeSalary(3500);
		
		empDaoImpl.updateEmployee(employee);
		*/
		
		//SELECT
		/*
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
		List<Employee> empList = empDaoImpl.getEmployees();
		
		for(Employee employee : empList) {
			
			System.out.println("Employee: "+employee);
		}
		*/		
		
		//INSERT
		/*
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
				
		Employee employee = new Employee();
		
		employee.setEmployeeNumber(104);
		employee.setEmployeeName("Clark");
		employee.setEmployeeJob("Clerk");
		employee.setEmployeeSalary(3000);
		
		empDaoImpl.addEmployee(employee);
		*/

	}

}
