package result.others;

import result.MyResult;

public class Friend {

	public void sneekResult() {
			
			MyResult myResult = new MyResult();
			
			System.out.println("Show me your username 		: "+myResult.userName); //not visible(default)
			System.out.println("Show me your password       : "+myResult.password); //not visible(private)
			System.out.println("How much marks did you score: "+myResult.marksObtained);	//not visible(protected)
	}

}