package result;

import java.time.LocalDate;

public class MyResult {

	String userName = "abcd@1234";
	private String password = "rashik";
	public String fullName = "Rashi K";
	protected LocalDate dob = LocalDate.of(2002,5,5);
	protected float marksObtained = 79;
	
	void myResult() {
		System.out.println("Name: 			"+fullName);
		System.out.println("Username: 		"+userName);
		System.out.println("Password:		"+password);
		System.out.println("Date of birth:  "+dob);
		System.out.println("Marks obtained: "+marksObtained);
	}
	
}
