import result.others.Friend;

public class PackageTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Friend friend = new Friend();
		
		friend.sneekResult();

	}

}
