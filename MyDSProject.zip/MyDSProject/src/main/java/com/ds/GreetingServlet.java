package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class GreetingServlet
 */
@WebServlet({ "/greet", "/hi", "/hello" })
public class GreetingServlet extends GenericServlet {
	
    public GreetingServlet() {
        super();
        System.out.println("GreetServlet()...");
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("init()...");
	}

	public void destroy() {
		System.out.println("destroy()...");
	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("service(req,resp)");
		PrintWriter pw = response.getWriter();
		response.setContentType("Text/html");
		pw.println("<marquee><h2>welcome to the world of servlets</h2></marquee>");
		
	}

}
