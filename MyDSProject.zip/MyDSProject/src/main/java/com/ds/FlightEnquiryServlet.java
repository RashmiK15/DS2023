package com.ds;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FlightEnquiryServlet
 */
@WebServlet("/FlightEnquiry")
public class FlightEnquiryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public FlightEnquiryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    //doget and dopost are inherited from httpservlet class
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet() called...");
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost() called...");
		doGet(request, response);
	}

}
