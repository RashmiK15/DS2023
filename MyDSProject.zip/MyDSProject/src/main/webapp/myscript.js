/**
 * 
 */

alert('3..this is from myscript.js');